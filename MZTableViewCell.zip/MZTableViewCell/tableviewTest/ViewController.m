//
//  ViewController.m
//  tableviewTest
//
//  Created by iosh on 16/7/18.
//  Copyright © 2016年 iosh. All rights reserved.
//

#import "ViewController.h"
#import "MyCell.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

//cell高度记录
@property (strong,nonatomic) NSMutableDictionary *heightRecordDt;
//textView 内容记录
@property (strong,nonatomic) NSMutableDictionary *textViewStringDt;
//数据源
@property (strong,nonatomic) NSArray *stringArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _heightRecordDt = [[NSMutableDictionary alloc]init];
    _textViewStringDt = [[NSMutableDictionary alloc]init];
    
    self.stringArray = @[@"测试1",@"测试2",@"测试3",@"测试4",@"测试5",@"测试6",@"测试6",@"测试7",@"测试8",@"测试9",@"测试10",@"测试11",@"测试12",@"测试13",@"测试14",@"测试15",@"测试16",@"测试17",@"测试18",@"测试19",@"测试20"];
    
}
#pragma mark - tableView delegate
- (NSInteger )tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _stringArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *heightString = [_heightRecordDt objectForKey:indexPath];
    //设置最小高度
    if (heightString.floatValue < 44) {
        return 44;
    }else{
        return heightString.floatValue;
    }
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    MyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCell"];
    cell.MyTextView.delegate = self;
    cell.MyTextView.text = [_textViewStringDt objectForKey:indexPath];
    cell.MyTextView.tag = indexPath.section*1000 + indexPath.row;
    cell.MyTextView.scrollEnabled = NO;
    
    return cell;
}

#pragma mark - textView delegate
- (void)textViewDidChange:(UITextView *)textView{

    NSIndexPath *index = [NSIndexPath indexPathForRow:textView.tag%1000 inSection:textView.tag/1000];
    CGRect rect1 = textView.frame;
    CGSize maxSize = CGSizeMake(rect1.size.width, CGFLOAT_MAX);
    CGSize newSize = [textView sizeThatFits:maxSize];
    rect1.size = newSize;
    textView.frame = rect1;
    
    //保存内容，便于cell的复用
    [_textViewStringDt setObject:textView.text forKey:index];
    NSString *heightString = [_heightRecordDt objectForKey:index];
    //判断：当高度发生改变的时候才刷新cell
    //单独刷新一个cell
    if (rect1.size.height != heightString.floatValue) {
        //保存最新高度
        [_heightRecordDt setObject:[NSString stringWithFormat:@"%f",rect1.size.height+12] forKey:index];
        [_tableView beginUpdates];
        [_tableView endUpdates];
    }
}

@end
