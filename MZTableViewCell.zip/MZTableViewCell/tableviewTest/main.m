//
//  main.m
//  tableviewTest
//
//  Created by iosh on 16/7/18.
//  Copyright © 2016年 iosh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
