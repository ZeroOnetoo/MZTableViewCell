//
//  MyCell.m
//  tableviewTest
//
//  Created by iosh on 16/7/31.
//  Copyright © 2016年 iosh. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
