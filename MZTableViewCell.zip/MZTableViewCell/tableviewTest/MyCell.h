//
//  MyCell.h
//  tableviewTest
//
//  Created by iosh on 16/7/31.
//  Copyright © 2016年 iosh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UITableViewCell<UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UITextView *MyTextView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *textViewHeight;

@end

