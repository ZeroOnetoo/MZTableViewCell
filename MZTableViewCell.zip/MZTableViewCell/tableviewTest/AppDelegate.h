//
//  AppDelegate.h
//  tableviewTest
//
//  Created by iosh on 16/7/18.
//  Copyright © 2016年 iosh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

